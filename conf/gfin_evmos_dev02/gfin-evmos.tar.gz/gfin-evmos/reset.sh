#!/bin/sh
. ./env.sh
rm -rf ${EVMOSD_HOME}/config ${EVMOSD_HOME}/data ${EVMOSD_HOME}/keyring-file ${EVMOSD_HOME}/keyring-test
